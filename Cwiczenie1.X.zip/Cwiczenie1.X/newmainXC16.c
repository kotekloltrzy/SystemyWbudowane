/*
 * File:   newmainXC16.c
 * Author: local
 *
 * Created on May 6, 2026, 10:01 AM
 */

// PIC24FJ128GA010 Configuration Bit Settings

// 'C' source line config statements

// CONFIG2
#pragma config POSCMOD = XT             // Primary Oscillator Select (XT Oscillator mode selected)
#pragma config OSCIOFNC = ON            // Primary Oscillator Output Function (OSC2/CLKO/RC15 functions as port I/O (RC15))
#pragma config FCKSM = CSDCMD           // Clock Switching and Monitor (Clock switching and Fail-Safe Clock Monitor are disabled)
#pragma config FNOSC = PRI              // Oscillator Select (Primary Oscillator (XT, HS, EC))
#pragma config IESO = ON                // Internal External Switch Over Mode (IESO mode (Two-Speed Start-up) enabled)

// CONFIG1
#pragma config WDTPS = PS32768          // Watchdog Timer Postscaler (1:32,768)
#pragma config FWPSA = PR128            // WDT Prescaler (Prescaler ratio of 1:128)
#pragma config WINDIS = ON              // Watchdog Timer Window (Standard Watchdog Timer enabled,(Windowed-mode is disabled))
#pragma config FWDTEN = ON              // Watchdog Timer Enable (Watchdog Timer is enabled)
#pragma config ICS = PGx2               // Comm Channel Select (Emulator/debugger uses EMUC2/EMUD2)
#pragma config GWRP = OFF               // General Code Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF                // General Code Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = OFF             // JTAG Port Enable (JTAG port is disabled)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include "xc.h"
#include <libpic30.h>

void program1(void){
    unsigned int portValue;
    AD1PCFG = 0xFFFF;
    TRISA = 0x0000;
    
    while(1){
        for(int i = 0; i < 256; i++ ){
            portValue = i;
            LATA = portValue;
            __delay32(1000000);
        }
    }
}

void program2(void){
    unsigned int portValue;
    AD1PCFG = 0xFFFF;
    TRISA = 0x0000;
    
    while(1){
        for(int i = 255; i >= 0; i--){
            portValue = i;
            LATA = portValue;
            __delay32(1000000);
        }
    }
}

void program3(void){
    unsigned int gray;
    AD1PCFG = 0xFFFF;
    TRISA = 0x0000;
    
    while(1){
        for(unsigned int i = 0; i < 256; i++){
            gray = i ^ (i >> 1);
            LATA = gray;
            __delay32(1000000); 
        }
    }
}

void program4(void){
    unsigned int gray;
    AD1PCFG = 0xFFFF;
    TRISA = 0x0000;
    
    while(1){
        for(unsigned int i = 255; i >= 0; i--){
            gray = i ^ (i >> 1);
            LATA = gray;
            __delay32(1000000);
        }
    }
}

void program5(void) {
    unsigned int bcd;
    
    AD1PCFG = 0xFFFF;
    TRISA = 0x0000;
    
    while(1){
        for(int i = 0; i < 100; i++){
            int jednosci = i % 10;
            int dziesiatki = i / 10;
            bcd = (dziesiatki << 4) | jednosci;
            LATA = bcd;
            __delay32(1000000);
        }
    }
}

void program6(void){
    unsigned int bcd;
    
    AD1PCFG = 0xFFFF;
    TRISA = 0x0000;
    
    while(1){
        for(int i = 99; i >= 0; i--){
            int jednosci = i % 10;
            int dziesiatki = i / 10;
            bcd = (dziesiatki << 4) | jednosci;
            LATA = bcd;
            __delay32(1000000);
        }
    }
}

void program7(void){
    unsigned int waz;
    
    AD1PCFG = 0xFFFF;
    TRISA = 0x0000;
    
    while(1){
        for(int i = 7; i < 225; i = i * 2){
            waz = i;
            LATA = waz;
            __delay32(1000000);
        }
        for(int i = 112; i >= 14; i = i/2){
            waz = i;
            LATA = waz;
            __delay32(1000000);
        }
    }
}

void program8(void){
    unsigned int kol;
    
    AD1PCFG = 0xFFFF;
    TRISA = 0x0000;
    int a = 128;
    int j = 0;
    while(1){
        for(int i = 1; i < a+1; i = i*2){
            j = j + i;
            kol = j;
            LATA = kol;
            if(j == a){
                j = j + a;
                a = a/2;
            }
            kol = j;
            LATA = kol;
            __delay32(1000000);
        }
    }
}


int main(void) {
    program8();
    return 0;
}
